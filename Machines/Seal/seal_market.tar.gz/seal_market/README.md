Seal Market App
===============
A simple online market application which offers free shopping, avoid crowd in this pandemic situation, saves time. 

## ToDo
* Remove mutual authentication for dashboard, setup registration and login features.
* Deploy updated tomcat configuration.
* Disable manager and host-manager.
